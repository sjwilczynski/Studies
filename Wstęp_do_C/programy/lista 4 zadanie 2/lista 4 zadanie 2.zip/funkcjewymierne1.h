//Stanislaw Wilczynski 272955 Lista 4 zadanie 2 10.11.2014
#include<stdio.h>

#define BITY 32
typedef long long int wymierna;
typedef long long int lld;

lld nwd(lld a, lld b);
lld nww(lld a, lld b);

lld licznik(wymierna x);
lld mianownik(wymierna x);
wymierna tworz(lld lx,lld mx);
wymierna wczytaj();
void wypisz(wymierna x);
wymierna suma(wymierna x, wymierna y);
wymierna roznica(wymierna x,wymierna y);
wymierna iloczyn(wymierna x,wymierna y);
wymierna iloraz(wymierna x,wymierna y);

