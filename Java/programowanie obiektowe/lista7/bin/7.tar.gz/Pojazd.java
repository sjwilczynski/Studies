
public class Pojazd 
{
	protected String producent;
	protected String model;
	protected Integer wiek;
	public Pojazd(String p, String m, int w)
	{
		producent = p;
		model = m;
		wiek = w;
	}
	public Pojazd()
	{
		producent = "";
		model = "";
		wiek = 0;
	}
	public String toString()
	{
		String s = "";
		s += "Nasza maszyna to ";
		s += this.getClass().getName();
		s += " wyprodukowana przez ";
		s += producent;
		s += ". Model to ";
		s += model;
		s += ", ma lat ";
		s += wiek.toString();
		s +=".\n";
		return s;
	}
}
