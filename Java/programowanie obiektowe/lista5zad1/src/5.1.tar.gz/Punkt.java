
public class Punkt {

}
