
public class Wyrazenie 
{
	public String toString()
	{
		return this.toString();
	}
	public int oblicz()
	{
		return this.oblicz();
	}	
}

