
public class Okrag extends Figura 
{
	double R;
	Okrag(double r)
	{
		R=r;
	}
	public double pole()
	{
		return Math.PI*R*R;
	}

}
