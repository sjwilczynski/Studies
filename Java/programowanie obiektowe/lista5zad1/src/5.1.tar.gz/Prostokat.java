
public class Prostokat extends Figura
{
	double a;
	double b;
	Prostokat(double x,double y)
	{
		a=x;
		b=y;
	}
	public double pole()
	{
		return a*b;
	}

}
