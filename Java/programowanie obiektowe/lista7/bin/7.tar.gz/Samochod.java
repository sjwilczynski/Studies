
public class Samochod extends Pojazd 
{
	protected Integer przebieg;
	protected String paliwo;
	protected String opony;
	public Samochod(String p, String m, int w, int prz, String pal, String o)
	{
		super(p,m,w);
		przebieg  = prz;
		paliwo = pal;
		opony = o;
	}
	public Samochod()
	{
		super();
		przebieg = 0;
		paliwo = "";
		opony = "";
	}
	public String toString()
	{
		String s = "";
		s += super.toString();
		s += "Jego przebieg to ";
		s += przebieg.toString();
		s += ", jezdzi na ";
		s += paliwo;
		s += ", a uzywa opon ";
		s += opony;
		s += ".\n";
		return s;
	}

}
