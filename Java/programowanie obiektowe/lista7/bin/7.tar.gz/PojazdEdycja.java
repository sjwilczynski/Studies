
public interface PojazdEdycja {

}
