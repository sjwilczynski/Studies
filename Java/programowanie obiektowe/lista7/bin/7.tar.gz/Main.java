


public class Main
{
	public static void main(String[] args)
	{
		Pojazd[] P = new Pojazd[3];
		P[0] = new Pojazd("Ciagnik","czarny",20);
		P[1] = new Tramwaj("Skoda","Nowa",1,33,"Pilczyce","Stadion");
		P[2] = new Samochod("Toyota","Yaris",5,100000,"benzyna","Continental");
		//for(int i = 0; i <= 2; i ++)System.out.print(P[i].toString());
		//System.out.print(P[0].toString());
		PojazdEdit x = new PojazdEdit(P[0]);
		x.start();
		//System.out.print(P[0].toString());
	}

}
