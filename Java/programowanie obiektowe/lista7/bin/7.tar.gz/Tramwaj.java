
public class Tramwaj extends Pojazd 
{
	protected Integer numer;
	protected String poczatek;
	protected String koniec;
	public Tramwaj(String p, String m, int w, int n, String pocz, String kon)
	{
		super(p,m,w);
		numer = n;
		poczatek = pocz;
		koniec =kon;
	}
	public Tramwaj()
	{
		super();
		numer = 0;
		poczatek = "";
		koniec = "";
	}
	public String toString()
	{
		String s = "";
		s += super.toString();
		s += "Jego numer to ";
		s += numer.toString();
		s += ", trase zaczyna na przystanku ";
		s += poczatek;
		s += ", a konczy na przystanku ";
		s += koniec;
		s += ".\n";
		return s;
	}

}
