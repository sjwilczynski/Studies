# coding= utf-8
"""Wywołanie funkcji uruchomserwer() z pliku serwer"""
import serwer

serwer.uruchomserwer()